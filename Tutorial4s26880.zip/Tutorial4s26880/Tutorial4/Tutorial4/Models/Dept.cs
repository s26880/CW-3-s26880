namespace Tutorial3.Models;

public class Dept
{
    public int DeptNo { get; set; }
    public string DName { get; set; }
    public string Loc { get; set; }
}
